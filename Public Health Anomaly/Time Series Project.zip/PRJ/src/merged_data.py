# src/merged_data.py

import sys
import os

# Ensure root directory is in Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.load_data import load_data1, load_data2,load_data3
import pandas as pd

def merge_and_save():
    df_ili = load_data1()
    df_lab = load_data2()
    df_lab1 = load_data3()

    # Merge on datetime (ds)
    df = pd.merge(df_ili, df_lab, on='ds', how='inner')

    # Save merged dataset
    os.makedirs('data/processed', exist_ok=True)
    df.to_csv('data/processed/merged_data.csv', index=False)
    print("done")

if __name__ == "__main__":
    merge_and_save()
