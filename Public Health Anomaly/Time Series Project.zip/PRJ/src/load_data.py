# src/load_data.py

import pandas as pd

def load_data1(path=r'C:\Users\naman\OneDrive\Desktop\PRJ\data\raw\ILINet.csv'):
    # Skip first line if it's metadata or title
    df = pd.read_csv(path, skiprows=1)

    # Auto-detect the % WEIGHTED ILI column
    expected_col = "% WEIGHTED ILI"
    actual_col = next((col for col in df.columns if expected_col.lower() in col.lower()), None)

    if not actual_col:
        raise ValueError("Could not find '% WEIGHTED ILI' column in ilinet.csv")

    # Drop missing values
    df = df[df[actual_col].notna()]
    df['Week'] = df['WEEK'].astype(int)
    df['Year'] = df['YEAR'].astype(int)

    # Build datetime column
    df['ds'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Week'].astype(str) + '-1', format='%Y-%W-%w')

    # Rename the ILI column to 'y' for modeling
    df = df.rename(columns={actual_col: "y"})

    return df[['ds', 'y']]

def load_data2(path=r'C:\Users\naman\OneDrive\Desktop\PRJ\data\raw\ICL_NREVSS_Public_Health_Labs.csv'):
    df = pd.read_csv(path, skiprows=1)  # skip metadata if present

    df = df[df['TOTAL SPECIMENS'].notna()]
    df['Week'] = df['WEEK'].astype(int)
    df['Year'] = df['YEAR'].astype(int)
    df['ds'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Week'].astype(str) + '-1', format='%Y-%W-%w')

    # Subtype columns to keep
    subtypes = ['A (2009 H1N1)', 'A (H3)', 'A (Subtyping not Performed)', 'B', 'BVic', 'BYam', 'H3N2v', 'A (H5)']

    for subtype in subtypes:
        if subtype not in df.columns:
            df[subtype] = 0  # Add missing subtype columns as zeros

    df[subtypes] = df[subtypes].fillna(0)
    return df[['ds', 'TOTAL SPECIMENS'] + subtypes]

