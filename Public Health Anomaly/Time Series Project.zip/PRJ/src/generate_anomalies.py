# src/generate_anomalies.py

import pandas as pd
from pyod.models.iforest import IForest
from sklearn.preprocessing import StandardScaler

# Load merged data
df = pd.read_csv(r"C:\Users\naman\OneDrive\Desktop\PRJ\data\processed\merged_data.csv")
df['ds'] = pd.to_datetime(df['ds'])

# Select features for anomaly detection
features = ['y', 'TOTAL SPECIMENS', 'A (H3)', 'B', 'BVic', 'BYam']
X = df[features].fillna(0)

# Normalize
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Fit IForest model
model = IForest()
model.fit(X_scaled)
df['anomaly'] = model.predict(X_scaled)  # 1 = anomaly

# Save
df.to_csv("data/processed/merged_with_anomalies.csv", index=False)
print("✅ merged_with_anomalies.csv saved with 'anomaly' column.")
