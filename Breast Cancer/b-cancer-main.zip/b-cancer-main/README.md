# b-cancer


basic ml project based on numeric data.Good for understand SKLEARN 
